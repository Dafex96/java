package modelo;
import java.sql.Connection;
import java.sql.PreparedStatement;

public class VehiculoDAO {
    
    private Conexion conexion = new Conexion();
    
    public void insertar(Vehiculo vehiculo){
        String sentencia = "INSERT INTO vehiculo VALUES (?,?,?,?,?)";
        try{
            Connection con = conexion.getConexion();
            PreparedStatement ps = con.prepareStatement(sentencia);
            
            ps.setString(1, vehiculo.getPatente());
            ps.setString(2, vehiculo.getMarca());
            ps.setString(3, vehiculo.getModelo());
            ps.setInt(4, vehiculo.getAnio());
            ps.setInt(5, vehiculo.getKilometraje());
            
            ps.executeQuery();
        }catch(Exception error){
            System.out.println("Error: "+ error.getMessage());
        }
    }
}