package gestionvehiculoscrud;
import controldor.ControladorVehiculos;
import modelo.VehiculoDAO;
import vista.VistaVehiculos;

public class GestionVehiculosCRUD {
    public static void main(String[] args) {
        
        VistaVehiculos vista = new VistaVehiculos();
        VehiculoDAO dao = null;
        
        ControladorVehiculos controlador = new ControladorVehiculos(vista,dao);
        
        
    }   
}