package modelo;
import java.util.List;
import java.util.ArrayList;
import java.sql.*;
// import java.sql.* = importa todo de sql

public class VehiculoDAO {
    
    private Conexion conexion = new Conexion();
    
    public void insertar(Vehiculo vehiculo){
        String sentencia = "INSERT INTO vehiculos VALUES (?,?,?,?,?)";
        try{
            Connection con = conexion.getConexion();
            PreparedStatement ps = con.prepareStatement(sentencia);
            
            ps.setString(1, vehiculo.getPatente());
            ps.setString(2, vehiculo.getMarca());
            ps.setString(3, vehiculo.getModelo());
            ps.setInt(4, vehiculo.getAnio());
            ps.setInt(5, vehiculo.getKilometraje());
            
            ps.executeQuery();
            
            System.out.println("Enviado con exito");
            
        }catch(Exception error){
            System.out.println("Error: "+ error.getMessage());
        }
    }
    
    public List<Vehiculo> leer(){
        
        String sentencia = "SELECT * FROM vehiculos";
        List<Vehiculo> listaVehiculos = new ArrayList<>();
        try{
            Connection con = conexion.getConexion();
            Statement declaracion = con.createStatement();
            
            ResultSet resultadoConsulta = declaracion.executeQuery(sentencia);
            
            while(resultadoConsulta.next()){
                
                String patente = resultadoConsulta.getString("patente");
                String marca = resultadoConsulta.getString("marca");
                String modelo = resultadoConsulta.getString("modelo");
                int anio = resultadoConsulta.getInt("anio");
                int kilometraje = resultadoConsulta.getInt("kilometraje");
                
                Vehiculo vehiculo = new Vehiculo(patente, marca, modelo, anio, kilometraje);
                
                listaVehiculos.add(vehiculo);
            }            
        }catch(Exception error){
            System.out.println("Error al ingresar datos: " + error.getMessage());
        }
        return listaVehiculos;
    }
}