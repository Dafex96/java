package cl.hospital.hospital_vm.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import cl.hospital.hospital_vm.model.Paciente;
import cl.hospital.hospital_vm.repository.PacienteRepository;
import jakarta.transaction.Transactional;

@Service
@Transactional
public class PacienteService {

    @Autowired
    private PacienteRepository repo;

    public Paciente buscarporCorreo(String correo){
        return repo.findByCorreo(correo);
    }

    public List<Paciente> buscarPorNombre(String nombre){
        return repo.findByNombre(nombre);
    }

    public Paciente buscarPorId(Long id){
        return repo.findById(id).get();
    }

    public List<Paciente> mostarTodos(){
        return repo.findAll();
    }

    public void guardarPaciente(Paciente paciente){
        repo.save(paciente);
    }

    public void eliminar(Long id){
        repo.deleteById(id);
    }

}
