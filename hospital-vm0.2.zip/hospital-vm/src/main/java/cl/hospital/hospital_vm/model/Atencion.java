package cl.hospital.hospital_vm.model;

import java.util.Date;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "atencion")
public class Atencion {

       @Id
       @GeneratedValue(strategy = GenerationType.IDENTITY)
       private Integer id;

       @Column(nullable = false)
       private Date fechaAtencion;

       @Column(nullable = false)
       private String diagnostico;

       @ManyToOne(fetch = FetchType.EAGER)
       @JoinColumn(name = "paciente_id", nullable = false)
       private Paciente paciente;

       /*
              @ManyToOne : define la relacion que tendria en la base de datos respecto al objeto de tipo Paciente
                            FetchType.EAGER -> nos permie trabajar con el objeto y todos sus datos, no solo el id
              @JoinColumn : crea una tabla en la BD para guardar el id(pk) del paciente

       
       */

}
