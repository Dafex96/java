package cl.hospital.hospital_vm.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import cl.hospital.hospital_vm.model.Atencion;
import cl.hospital.hospital_vm.repository.AtencionRepository;
import jakarta.transaction.Transactional;

@Service
@Transactional
public class AtencionService {

       @Autowired
       private AtencionRepository repo;

       public List<Atencion> listarAtencion(){
              return repo.findAll();
       }

       public void guardarAtencion(Atencion atencion){
              repo.save(atencion);
       }

       public Atencion buscarAtencionPorId(Integer id){
              return repo.findById(id).get();
       }

       public void eliminarAtencion(Integer id){
        repo.deleteById(id);
       }

       public List<Atencion> buscarAtencionPorIdPaciente(Integer id){
              return repo.findByPacienteId(id);
       }
}
