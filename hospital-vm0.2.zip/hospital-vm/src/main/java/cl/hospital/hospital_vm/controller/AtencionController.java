package cl.hospital.hospital_vm.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import cl.hospital.hospital_vm.model.Atencion;
import cl.hospital.hospital_vm.service.AtencionService;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;


@RestController
@RequestMapping("api/v1/atenciones")
public class AtencionController {

       @Autowired
       private AtencionService service;

       @GetMapping
       public ResponseEntity<List<Atencion>> listarAtenciones(){
           List<Atencion> listaAtenciones = service.listarAtencion();
           if (listaAtenciones.isEmpty()) {
              return ResponseEntity.noContent().build();
           }else{
              return ResponseEntity.notFound().build();
           }
       }
       
       @PostMapping
       public void guardar (Atencion atencion){
           service.guardarAtencion(atencion);
       }
       
       @GetMapping("/{id}")
       public ResponseEntity<Atencion> buscarPorId(Integer id) {
              try{
                     Atencion atencion = service.buscarAtencionPorId(id);
                     return ResponseEntity.ok(atencion);
              }catch(Exception e){
                     return ResponseEntity.notFound().build();
              }
       }

       @DeleteMapping("/{id}")
       public ResponseEntity<?> eliminar(@PathVariable Integer id){
              try {
                     service.eliminarAtencion(id);
                     return ResponseEntity.noContent().build();
              } catch (Exception e) {
                     return ResponseEntity.notFound().build();
              }
       }

       @GetMapping("/paciente/{idPaciente}")
       public ResponseEntity<List<Atencion>> buscarAtencionPorPaciente(@PathVariable Integer idPaciente){
              List<Atencion> atenciones = service.buscarAtencionPorIdPaciente(idPaciente);

              if (atenciones.isEmpty()) {
                     return ResponseEntity.noContent().build();
              }else{
                     return ResponseEntity.ok(atenciones);
              }
       }

       






}
