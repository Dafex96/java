package cl.hospital.hospital_vm.repository;

import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import cl.hospital.hospital_vm.model.Atencion;

public interface AtencionRepository extends JpaRepository<Atencion, Integer>{

       List<Atencion> findByPacienteId(Integer id);
}
