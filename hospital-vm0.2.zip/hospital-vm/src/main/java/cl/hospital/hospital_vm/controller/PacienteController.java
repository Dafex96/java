package cl.hospital.hospital_vm.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import cl.hospital.hospital_vm.model.Paciente;
import cl.hospital.hospital_vm.service.PacienteService;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;


@RestController
@RequestMapping("api/v1/pacientes")
public class PacienteController {

    @Autowired
    private PacienteService service;

    @GetMapping("/{id}")
    public Paciente buscarPorId(@PathVariable Long id) {
        return service.buscarPorId(id);
    }
    
    @GetMapping
    public List<Paciente> mostarTodos() {
        return service.mostarTodos();
    }
    
    @PostMapping
    public void guardarPaciente(@RequestBody Paciente paciente) {
        service.guardarPaciente(paciente);
    }
    
    @DeleteMapping("/{id}")
    public void borrarPaciente(@PathVariable Long id){
        service.eliminar(id);
    }

}
