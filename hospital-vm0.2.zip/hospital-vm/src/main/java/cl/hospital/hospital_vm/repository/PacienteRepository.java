package cl.hospital.hospital_vm.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import cl.hospital.hospital_vm.model.Paciente;
import java.util.List;


public interface PacienteRepository extends JpaRepository<Paciente, Long>{

    Paciente findByCorreo(String correo);

    List<Paciente> findByNombre(String nombre);

    

}
