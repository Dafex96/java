package controldor;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;
import javax.swing.table.DefaultTableModel;
import modelo.Vehiculo;
import vista.VistaVehiculos;
import modelo.VehiculoDAO;

public class ControladorVehiculos implements ActionListener{
    
    private VistaVehiculos vista;
    private VehiculoDAO vehiculoDAO;

    public ControladorVehiculos(VistaVehiculos vista, VehiculoDAO vehiculoDAO) {
        this.vista = vista;
        this.vehiculoDAO = vehiculoDAO;
        this.vista.getBtnGuardar().addActionListener(this);
        this.vista.getBtnCargar().addActionListener(this);
    }
    
    @Override
    public void actionPerformed(ActionEvent evento) {
        
        if(evento.getSource() == vista.getBtnGuardar()){
            guardarVehiculo();
        }else if(evento.getSource() == vista.getBtnCargar()){
            
        }
    }
    
    public void guardarVehiculo(){
        
        String patente = vista.getTxtPatente().getText();
        String modelo = vista.getTxtModelo().getText();
        String marca = vista.getTxtMarca().getText();
        int anio = Integer.parseInt(vista.getTxtAnio().getText());
        int kilometraje = Integer.parseInt(vista.getTxtKilometraje().getText());
        
        Vehiculo vehiculo = new Vehiculo(patente, marca, modelo, anio, kilometraje);
        vehiculoDAO.insertar(vehiculo);
    }
    
    public void cargarTabla(){
        DefaultTableModel modeloTabla = vista.getModeloTabla();
        modeloTabla.setRowCount(0);
        
        List<Vehiculo> listaVehiculos = vehiculoDAO.leer();
        
        for(Vehiculo vehiculo : listaVehiculos){
            modeloTabla.addRow(new Object[]{
            vehiculo.getPatente(),
            vehiculo.getMarca(),
            vehiculo.getModelo(),
            vehiculo.getAnio(),
            vehiculo.getKilometraje()
            });
        }
    }
}