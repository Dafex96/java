package com.mycompany.petshop;
import java.util.Scanner;

public class PetShop {
    public static void main(String[] args) {
        
        Scanner input = new Scanner(System.in);
        
        int opt = 0;
        
        do{
            
            System.out.println("--Masacotas--");
            System.out.println("1) Agregar perro");
            System.out.println("2) Agregar gato");
            System.out.println("3) Agregar conejo");
            System.out.println("4) Salir");
            
            opt = input.nextInt();
            
            if(opt == 1){
                
                System.out.println("Ingrese el id del perro: ");
                String idPerro = input.next();
                
                System.out.println("Ingrese el alimento del perro: ");
                String alimento = input.next();
                
                System.out.println("Ingrese la cantidad de salidas diarias: ");
                int salidas = input.nextInt();
                
                //Mascota mascota = new Mascota(idPerro, alimento, salidas);
    
                
            }
            
            
            
            
            
            
            
        }while(opt != 5);
    }
}