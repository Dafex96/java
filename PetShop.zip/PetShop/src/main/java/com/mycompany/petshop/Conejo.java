package com.mycompany.petshop;

public class Conejo extends Mascota{
    
    private boolean comparteJaula;

    public Conejo(String idMascota, String alimento) {
        super(idMascota, alimento);
    }

    @Override
    public double calcularValorFinal() {
        
        double valorFinal = VALOR_BASE;
        
        if(comparteJaula = true){
            
            valorFinal = valorFinal * 1.07;
            
        }
        
        return valorFinal;
        
    }
}
