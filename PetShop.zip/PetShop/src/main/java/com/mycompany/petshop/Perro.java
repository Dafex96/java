package com.mycompany.petshop;

public class Perro extends Mascota{
    
    private int salidasDiarias;

    public Perro(String idMascota, String alimento) {
        super(idMascota, alimento);
    }

    @Override
    public double calcularValorFinal() {
        double valorFinal = VALOR_BASE;
        
        if(salidasDiarias > 3){
            valorFinal = valorFinal * 1.07;
        }
        
        return valorFinal;
        
    }
}
