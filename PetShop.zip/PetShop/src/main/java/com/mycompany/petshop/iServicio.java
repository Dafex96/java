package com.mycompany.petshop;

public interface iServicio {
    
    double VALOR_BASE = 25000;
    
    double calcularValorFinal();
    
}
