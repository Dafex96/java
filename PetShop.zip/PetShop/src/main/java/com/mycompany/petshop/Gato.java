package com.mycompany.petshop;

public class Gato extends Mascota{

    public Gato(String idMascota, String alimento) {
        super(idMascota, alimento);
    }

    @Override
    public double calcularValorFinal() {
        
        return VALOR_BASE * 1.05;
        
    }
}
