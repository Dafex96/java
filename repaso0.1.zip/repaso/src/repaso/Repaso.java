package repaso;

import java.util.Scanner;

public class Repaso {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        Empresa empre = new Empresa("Empresa DUOC");
        int opcion;

        do {
            System.out.println("1) Mostrar todos los empleados.");
            System.out.println("2) Contratar empleados.");
            System.out.println("3) Despedir empleado.");
            System.out.println("4) Buscar empleado por nombre.");
            System.out.println("5) Salir.");
            opcion = input.nextInt();

            if (opcion == 1) {
                System.out.println("PLANILLA EMPLEADO");
                empre.mostrarEmpleados();
            } else if (opcion == 2) {
                System.out.println("CONTRATAR EMPLEADO");

                System.out.println("Ingrese el rut: ");
                String rut = input.next();

                System.out.println("Ingrese el nombre: ");
                String nombreCompleto = input.next();

                System.out.println("Ingrese el genero: ");
                String genero = input.next();

                System.out.println("Ingrese la edad: ");
                int edad = input.nextInt();

                System.out.println("Ingrese el codigo del puesto: ");
                int codPuesto = input.nextInt();

                System.out.println("Ingrese el nombre del puesto: ");
                String nombrePuesto = input.next();

                Puesto puesto = new Puesto(codPuesto, nombrePuesto);
                Empleado emp = new Empleado(rut, nombreCompleto, genero, edad, puesto);

                empre.contratar(emp);

            } else if (opcion == 3) {
                System.out.println("DESPEDIR EMPLEADO");

                System.out.println("Ingrese el RUT a despedir: ");
                String rut = input.next();

                empre.despedir(rut);

            } else if (opcion == 4) {
                System.out.println("BUSCAR EMPLEADO");

                System.out.println("Ingrese el nombre del empleado: ");
                String nombre = input.next();

                empre.buscar(nombre);

            } else if (opcion == 5) {
                System.out.println("SALIENDO DEL SISTEMA...");
            } else {
                System.out.println("INGRESE UNA OPCION VALIDA");
            }
        } while (opcion != 5);

    }
}
