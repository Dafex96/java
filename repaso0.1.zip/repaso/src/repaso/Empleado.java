package repaso;

public class Empleado {

    private String rut;
    private String nombreCompleto;
    private String genero;
    private int añosServicio;
    private int edad;
    private Puesto puesto;

    public Empleado() {
    }

    public Empleado(String rut, String nombreCompleto, String genero, int edad, Puesto puesto) {
        this.rut = rut;
        this.nombreCompleto = nombreCompleto;
        this.genero = genero;
        this.añosServicio = 0;
        this.edad = edad;
        this.puesto = puesto;
    }

    public void mostrarEmpleado() {
        System.out.println("****************************");
        System.out.println("Nombre: " + nombreCompleto);
        System.out.println("RUT: " + rut);
        System.out.println("Genero: " + genero);
        System.out.println("Años de servicio: " + añosServicio);
        System.out.println("Edad: " + edad);
        System.out.println("Puesto: " + puesto.getNombre());
    }

    public String getRut() {
        return rut;
    }

    public void setRut(String rut) {
        this.rut = rut;
    }

    public String getNombreCompleto() {
        return nombreCompleto;
    }

    public void setNombreCompleto(String nombreCompleto) {
        this.nombreCompleto = nombreCompleto;
    }

    public String getGenero() {
        return genero;
    }

    public void setGenero(String genero) {
        this.genero = genero;
    }

    public int getAñosServicio() {
        return añosServicio;
    }

    public void setAñosServicio(int añosServicio) {
        this.añosServicio = añosServicio;
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    public Puesto getPuesto() {
        return puesto;
    }

    public void setPuesto(Puesto puesto) {
        this.puesto = puesto;
    }
}
