package repaso;

import java.util.ArrayList;
import java.util.List;

public class Empresa {

    private String nombre;
    private List<Empleado> empleados;

    public Empresa() {
    }

    public Empresa(String nombre) {
        this.nombre = nombre;
        this.empleados = new ArrayList<>();
    }

    public void mostrarEmpleados() {
        if (empleados.size() == 0) {
            System.out.println("No hay empleados");
        } else {
            for (Empleado emple : empleados) {
                emple.mostrarEmpleado();
            }
        }
    }

    public void contratar(Empleado emp) {
        empleados.add(emp);
        System.out.println("Empleado agregado con exito");
    }

    public void despedir(String rut) {
        int pos = -1;
        for (Empleado empleado : empleados) {
            if (empleado.getRut().equals(rut)) {

                pos = empleados.indexOf(empleado);
            }
        }
        if (pos == -1) {
            System.out.println("No se encontro ningun empleado");
        } else {
            empleados.remove(pos);
            System.out.println("Empleado eliminado");
        }
    }

    public void buscar(String nombreBusqueda) {
        for (Empleado empleado : empleados) {
            if (empleado.getNombreCompleto() == nombreBusqueda) {
                empleado.mostrarEmpleado();
            }
        }
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public List<Empleado> getEmpleados() {
        return empleados;
    }

    public void setEmpleados(List<Empleado> empleados) {
        this.empleados = empleados;
    }
}
