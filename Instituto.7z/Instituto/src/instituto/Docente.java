package instituto;

public class Docente {
    
    private String rut;
    private int numeroDocente;
    private String nombre;
    private String fechaIngreso;
    private String sede;

    public Docente() {
    }

    public Docente(String rut, int numeroDocente, String nombre, String fechaIngreso, String sede) {
        this.rut = rut;
        this.numeroDocente = numeroDocente;
        this.nombre = nombre;
        this.fechaIngreso = fechaIngreso;
        this.sede = sede;
    }

    public String getRut() {
        return rut;
    }

    public int getNumeroDocente() {
        return numeroDocente;
    }

    public String getNombre() {
        return nombre;
    }

    public String getFechaIngreso() {
        return fechaIngreso;
    }

    public String getSede() {
        return sede;
    }

    public void setRut(String rut) {
        this.rut = rut;
    }

    public void setNumeroDocente(int numeroDocente) {
        this.numeroDocente = numeroDocente;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setFechaIngreso(String fechaIngreso) {
        this.fechaIngreso = fechaIngreso;
    }

    public void setSede(String sede) {
        this.sede = sede;
    }
    
    
    
    
    
    
    
}
