package instituto;
import java.util.Scanner;

public class Instituto {

    public static void main(String[] args) {
        
        Scanner input = new Scanner(System.in);
        
        int opt;
        
        do{
            
            System.out.println("1) Ingreso alumno.");
            System.out.println("2) Ingreso docente.");
            
            opt = input.nextInt();
            
        }while(opt>0);
        
        
        if(opt==1){
            
            
            
            
            
            
        }
        
        
        
        
        
        
    }
    
}
