package instituto;

public class Docente {
    
    private String rut;
    private String nombre;
    private int nroDocente;
    private String fechaIngreso;
    private Sede sede;

    public Docente() {
    }

    public Docente(String rut, String nombre, int nroDocente, String fechaIngreso, Sede sede) {
        this.rut = rut;
        this.nombre = nombre;
        this.nroDocente = nroDocente;
        this.fechaIngreso = fechaIngreso;
        this.sede = sede;
    }

    public String getRut() {
        return rut;
    }

    public void setRut(String rut) {
        this.rut = rut;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getNroDocente() {
        return nroDocente;
    }

    public void setNroDocente(int nroDocente) {
        this.nroDocente = nroDocente;
    }

    public String getFechaIngreso() {
        return fechaIngreso;
    }

    public void setFechaIngreso(String fechaIngreso) {
        this.fechaIngreso = fechaIngreso;
    }

    public Sede getSede() {
        return sede;
    }

    public void setSede(Sede sede) {
        this.sede = sede;
    }
    
    
    
}
