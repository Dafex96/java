package instituto;

public class Sede {
    
    private String nombre;
    private String direccion;
    private String sigla;

    public Sede() {
    }
    
    public Sede(String nombre, String direccion, String sigla) {
        this.nombre = nombre;
        this.direccion = direccion;
        this.sigla = sigla;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public String getSigla() {
        return sigla;
    }

    public void setSigla(String sigla) {
        this.sigla = sigla;
    }
    
    
    
    
}
