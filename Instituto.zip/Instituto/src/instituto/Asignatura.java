package instituto;

public class Asignatura {
    
    private int codAsignatura;
    private String nombre;
    private Alumno alumno;
    private Docente docente;
    private double nota1;
    private double nota2;
    private double nota3;

    public Asignatura() {
    }

    public Asignatura(int codAsignatura, String nombre, Alumno alumno, Docente docente) {
        this.codAsignatura = codAsignatura;
        this.nombre = nombre;
        this.alumno = alumno;
        this.docente = docente;
        this.nota1=0;
        this.nota2=0;
        this.nota3=0;
    }
    
    public double getPromedio(){
        double promedio = (nota1+nota2+nota3)/3;
        return promedio;
    }
    
    
    public int getCodAsignatura() {
        return codAsignatura;
    }

    public void setCodAsignatura(int codAsignatura) {
        this.codAsignatura = codAsignatura;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public Alumno getAlumno() {
        return alumno;
    }

    public void setAlumno(Alumno alumno) {
        this.alumno = alumno;
    }

    public Docente getDocente() {
        return docente;
    }

    public void setDocente(Docente docente) {
        this.docente = docente;
    }

    public double getNota1() {
        return nota1;
    }

    public void setNota1(double nota1) {
        this.nota1 = nota1;
    }

    public double getNota2() {
        return nota2;
    }

    public void setNota2(double nota2) {
        this.nota2 = nota2;
    }

    public double getNota3() {
        return nota3;
    }

    public void setNota3(double nota3) {
        this.nota3 = nota3;
    }
    
    
    
    
    
}
