package instituto;

import java.util.Scanner;

public class Instituto {

    public static void main(String[] args) {
        
        Scanner input = new Scanner(System.in);
        System.out.println("Ingrese el nombre de la sede: ");
        String nombreSede = input.next();
        
        Sede sede = new Sede(nombreSede, "Sta. Elena de Huechuraba","PN");
        
        Alumno alumno = new Alumno("1231234-4", "Maite", 15, "341234");
        
        Docente docente = new Docente("3423424-4", "Juan", 123, "34234", sede);
        
        Asignatura asignatura = new Asignatura(123, "Programacion", alumno, docente);
        asignatura.setNota1(3.8);
        asignatura.setNota2(3.9);
        asignatura.setNota3(1.5);
        
        System.out.println("El promedio es "+asignatura.getPromedio());
        
    }
    
}
