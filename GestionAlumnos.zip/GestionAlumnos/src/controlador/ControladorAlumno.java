package controlador;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import modelo.Alumno;
import modelo.Asignatura;
import vista.VistaAlumno;

public class ControladorAlumno implements ActionListener{
    
    private Asignatura asignatura;
    private VistaAlumno vista;

    public ControladorAlumno(Asignatura asignatura, VistaAlumno vista) {
        this.asignatura = asignatura;
        this.vista = vista;
        this.vista.getBntGuardar().addActionListener(this);
        this.vista.getBtnRefresh().addActionListener(this);
    }
    
    @Override
    public void actionPerformed(ActionEvent evento) {
        
        if (evento.getSource() == vista.getBntGuardar()){
            
            guardarAlumno();
            
        } else if (evento.getSource() == vista.getBtnRefresh()){
            
            mostrarAlumnos();
            
        }
        
    }
    
    private void guardarAlumno(){
        
        String nombre = vista.getTxtNombre().getText();
        String carrera = vista.getTxtCarrera().getText();
        int edad = Integer.parseInt(vista.getTxtEdad().getText());
        
        Alumno alumno = new Alumno(nombre, edad, carrera);
        asignatura.agregarAlumno(alumno);
    }
    
    private void mostrarAlumnos(){
        
        vista.getModeloTabla().setRowCount(0);
        
        for (Alumno alumno : asignatura.getListaAlumnos()){
            
            vista.getModeloTabla().addRow(new Object[]{
                                            alumno.getNombre(),
                                            alumno.getEdad(),
                                            alumno.getCarrera()
            });
            
        }
        
    }
    
}
