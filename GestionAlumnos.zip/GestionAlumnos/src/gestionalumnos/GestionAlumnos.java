package gestionalumnos;

import controlador.ControladorAlumno;
import modelo.Asignatura;
import vista.VistaAlumno;

public class GestionAlumnos {
    
    public static void main(String[] args) {
        
        Asignatura modelo = new Asignatura();
        VistaAlumno vista = new VistaAlumno();
        
        ControladorAlumno controlador = new ControladorAlumno(modelo,vista);
        
        vista.setLocationRelativeTo(null);
        vista.setVisible(true);
        
        vista.getTxtNombre().setText("");
        vista.getTxtCarrera().setText("");
        vista.getTxtEdad().setText("");
    }
    
}
