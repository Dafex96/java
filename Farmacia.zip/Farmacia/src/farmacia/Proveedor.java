package farmacia;

public class Proveedor {
    
    private String codigoPreoveedor;
    private String nombreProveedor;
    private String medSumin;

    public Proveedor() {
    }

    public Proveedor(String codigoPreoveedor, String nombreProveedor, String medSumin) {
        this.codigoPreoveedor = codigoPreoveedor;
        this.nombreProveedor = nombreProveedor;
        this.medSumin = medSumin;
    }
    
    
    
}
