package controlador;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.table.DefaultTableModel;
import modelo.Seguro;
import vista.VistaSalud;

public class ControladorSeguro implements ActionListener{
    
    private VistaSalud vista;

    public ControladorSeguro(VistaSalud vista) {
        this.vista = vista;
        this.vista.getBtnRefresh().addActionListener(this);
        this.vista.getBtnList().addActionListener(this);
    }

    @Override
    public void actionPerformed(ActionEvent evento) {
        if(evento.getSource() == vista.getBtnRefresh()){
            guardarSeguro();
        }else if(evento.getSource() == vista.getBtnList()){
            listarSeguro();
        }
    }
    
    public void guardarSeguro(){
        String nombre = vista.getTxtNombreSeguro().getText();
        String desc = vista.getTxtDescripcion().getText();
        String descCob = vista.getTxtDescCobertura().getText();
        double cob = Double.parseDouble(vista.getTxtCobertura().getText());
        
        Seguro seguro = new Seguro(nombre,desc,descCob,cob);
    }
    
    public void listarSeguro(){
        DefaultTableModel modeloTabla = vista.getModeloTabla();
        modeloTabla.setRowCount(0);
        
        
        
    }
}