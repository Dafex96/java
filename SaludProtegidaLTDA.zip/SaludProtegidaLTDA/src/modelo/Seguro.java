package modelo;

public class Seguro {
    
    private int idSeguro;
    private String nombreSeguro;
    private String descripcion;
    private String descCobertura;
    private double porcentajeCobertura;

    public Seguro(String nombreSeguro, String descripcion, String descCobertura, double porcentajeCobertura) {
        this.nombreSeguro = nombreSeguro;
        this.descripcion = descripcion;
        this.descCobertura = descCobertura;
        this.porcentajeCobertura = porcentajeCobertura;
    }

    public int getIdSeguro() {
        return idSeguro;
    }

    public void setIdSeguro(int idSeguro) {
        this.idSeguro = idSeguro;
    }

    public String getNombreSeguro() {
        return nombreSeguro;
    }

    public void setNombreSeguro(String nombreSeguro) {
        this.nombreSeguro = nombreSeguro;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public String getDescCobertura() {
        return descCobertura;
    }

    public void setDescCobertura(String descCobertura) {
        this.descCobertura = descCobertura;
    }

    public double getPorcentajeCobertura() {
        return porcentajeCobertura;
    }

    public void setPorcentajeCobertura(double porcentajeCobertura) {
        this.porcentajeCobertura = porcentajeCobertura;
    }
    
    
    
    
    
    
}
