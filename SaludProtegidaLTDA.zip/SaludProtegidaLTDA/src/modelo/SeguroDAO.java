package modelo;
import java.sql.*;

public class SeguroDAO extends conexion{
    
    private conexion conexion = new conexion();
    
    
    
    
}
