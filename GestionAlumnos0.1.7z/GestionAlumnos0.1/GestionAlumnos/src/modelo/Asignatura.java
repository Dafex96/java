package modelo;
import java.util.ArrayList;
import java.util.List;

public class Asignatura {
    
    private List<Alumno> listaAlumnos;

    public Asignatura() {
        this.listaAlumnos = new ArrayList<>();
    }
    
    public void agregarAlumno(Alumno alumno){
        listaAlumnos.add(alumno);
    }
    
    public List<Alumno> getListaAlumnos(){
        return listaAlumnos;
    }
    
    
}
