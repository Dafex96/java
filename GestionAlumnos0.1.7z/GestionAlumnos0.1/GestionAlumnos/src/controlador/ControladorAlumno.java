package controlador;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JOptionPane;
import modelo.Alumno;
import modelo.Asignatura;
import vista.VistaAlumno;

public class ControladorAlumno implements ActionListener{
    
    private Asignatura asignatura;
    private VistaAlumno vista;

    public ControladorAlumno(Asignatura asignatura, VistaAlumno vista) {
        this.asignatura = asignatura;
        this.vista = vista;
        this.vista.getBntGuardar().addActionListener(this);
        this.vista.getBtnRefresh().addActionListener(this);
    }
    
    @Override
    public void actionPerformed(ActionEvent evento) {
        
        if (evento.getSource() == vista.getBntGuardar()){
            
            guardarAlumno();
            
        } else if (evento.getSource() == vista.getBtnRefresh()){
            
            mostrarAlumnos();
            
        }
        
    }
    
    private void guardarAlumno(){
        
        try{
            
            
        
            String nombre = vista.getTxtNombre().getText();
            String carrera = vista.getTxtCarrera().getText();
            int edad = Integer.parseInt(vista.getTxtEdad().getText());
            
            if(nombre.isEmpty()|| carrera.isEmpty()){                
                throw new Exception("Todos los campos son obligatorios");
            }
            
            Alumno alumno = new Alumno(nombre, edad, carrera);
            asignatura.agregarAlumno(alumno);
        
            JOptionPane.showMessageDialog(vista, "Alumno agregado exitosamente!");
            
            vista.getTxtCarrera().setText("");
            vista.getTxtEdad().setText("");
            vista.getTxtNombre().setText("");
            
        }catch(NumberFormatException errorNumerico){
            JOptionPane.showMessageDialog(vista, "Error, La edad debe ser numero entero");
        }catch(Exception error){
            JOptionPane.showMessageDialog(vista, error.getMessage());
        }
        
    }
    
    private void mostrarAlumnos(){
        
        vista.getModeloTabla().setRowCount(0);
        
        for (Alumno alumno : asignatura.getListaAlumnos()){
            
            vista.getModeloTabla().addRow(new Object[]{
                                            alumno.getNombre(),
                                            alumno.getEdad(),
                                            alumno.getCarrera()
            });
            
        }
        
    }
    
}
