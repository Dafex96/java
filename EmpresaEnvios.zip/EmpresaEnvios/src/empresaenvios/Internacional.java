package empresaenvios;

public class Internacional extends Envio{
    
    private String paisDestino;
    private double tasaImpuesto;

    public Internacional(String paisDestino, double tasaImpuesto, String codigo, double pesoEnKg) {
        super(codigo, pesoEnKg);
        this.paisDestino = paisDestino;
        this.tasaImpuesto = tasaImpuesto;
    }
    
    @Override
    public double calcularValor(){
        double costoEnvio = tarifaBase + (pesoEnKg * 1500);
        double impuesto = costoEnvio * tasaImpuesto / 100;
        costoEnvio = costoEnvio * impuesto;
        return costoEnvio;
    }
    
    
}
