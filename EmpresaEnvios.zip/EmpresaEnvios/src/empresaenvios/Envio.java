package empresaenvios;

public abstract class Envio {
    
    private String codigo;
    double pesoEnKg;
    double tarifaBase = 2000;

    public Envio() {
    }

    public Envio(String codigo, double pesoEnKg) {
        this.codigo = codigo;
        this.pesoEnKg = pesoEnKg;
        this.tarifaBase = tarifaBase;
    }
    
    public abstract double calcularValor();
}
