package empresaenvios;
import java.util.Scanner;

public class EmpresaEnvios {
    public static void main(String[] args) {
        
        Scanner input = new Scanner(System.in);
        
        int opcion = 0;
        
        do{
            
            System.out.println("1) Calcular envio Nacional");
            System.out.println("2) Calcular envio Internacional");
            System.out.println("3) Salir");
            
            opcion = input.nextInt();
            
            if (opcion == 1){
                System.out.println("--ENVIO NACIONAL--");
                
                System.out.println("Ingrese la region de destino: ");
                String region = input.next();
                
                System.out.println("Ingrese el codigo del envio: ");
                String codigo = input.next();
                
                System.out.println("Ingrese el peso en KG:");
                double peso = input.nextDouble();
                
                Nacional envioNacional = new Nacional(region,codigo,peso);
                
                System.out.println("--DATOS ENVIO--");
                System.out.println("El envio calculado a " + envioNacional.getRegionDestino());
                System.out.println("Tiene un costo de: " + envioNacional.calcularValor());
                
            }else if (opcion == 2){
                System.out.println("--ENVIO INTERNACIONA--");
                
                System.out.println("Ingrese el pais de destino: ");
                String pais = input.next();
                
                System.out.println("Ingrese el codigo ");
                
            }else if (opcion == 3){
                System.out.println("Saliendo...");
                
            }else {
                System.out.println("Ingrese una opcion valida...");
            }
           
            
            
            
        }while(opcion != 4);
                
        
        
        
    }
    
}
