package empresaenvios;

public class Nacional extends Envio{
    
    private String regionDestino;

    public Nacional(String regionDestino) {
        this.regionDestino = regionDestino;
    }

    public Nacional(String regionDestino, String codigo, double pesoEnKg) {
        super(codigo, pesoEnKg);
        this.regionDestino = regionDestino;
    }
    
    @Override
    public double calcularValor() {
        
        double costoEnvio = tarifaBase + (pesoEnKg * 500);
        return costoEnvio;
    }

    public String getRegionDestino() {
        return regionDestino;
    }

    public void setRegionDestino(String regionDestino) {
        this.regionDestino = regionDestino;
    }

    public double getPesoEnKg() {
        return pesoEnKg;
    }

    public void setPesoEnKg(double pesoEnKg) {
        this.pesoEnKg = pesoEnKg;
    }

    public double getTarifaBase() {
        return tarifaBase;
    }

    public void setTarifaBase(double tarifaBase) {
        this.tarifaBase = tarifaBase;
    }
    
    
    
}
