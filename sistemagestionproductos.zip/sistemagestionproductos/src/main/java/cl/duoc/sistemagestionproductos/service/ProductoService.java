package cl.duoc.sistemagestionproductos.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import cl.duoc.sistemagestionproductos.model.Producto;
import cl.duoc.sistemagestionproductos.repository.ProductoRepository;

@Service
public class ProductoService {

    @Autowired
    private ProductoRepository productoRepository;

    public List<Producto> getProductos(){
        return productoRepository.mostrarProductos();
    }

    public boolean deleteProducto(String nombre){
        return productoRepository.eliminarProducto(nombre);
    }

    public void saveProducto(Producto prod){
        productoRepository.agregarProducto(prod);
    }
}
