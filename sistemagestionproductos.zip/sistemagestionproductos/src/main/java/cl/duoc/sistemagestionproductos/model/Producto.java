package cl.duoc.sistemagestionproductos.model;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class Producto {

    @NotNull(message = "El nombre es obligatoio")
    @Size(min = 2, max = 25, message = "El maximo de caracteres son 25")
    private String nombre;

    @NotNull
    @Positive(message = "El precio debe ser un numero positivo")
    private int precio;

    @NotBlank
    private String categoria;

}
