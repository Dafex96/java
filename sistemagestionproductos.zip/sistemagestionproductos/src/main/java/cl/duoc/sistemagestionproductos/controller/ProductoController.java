package cl.duoc.sistemagestionproductos.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
import cl.duoc.sistemagestionproductos.model.Producto;
import cl.duoc.sistemagestionproductos.service.ProductoService;
import jakarta.validation.Valid;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

@RestController
@RequestMapping("/api/v1/productos")
public class ProductoController {

    @Autowired
    private ProductoService productoService;

    @GetMapping
    @ResponseStatus(HttpStatus.OK)
    public List<Producto> mostrarProductos() {
        return productoService.getProductos();
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public void agregarProducto(@RequestBody @Valid Producto prod){
        productoService.saveProducto(prod);
    }

    @DeleteMapping("/{nombre}")
    public ResponseEntity<Boolean> eliminarProducto(@PathVariable String nombre){

        if (productoService.deleteProducto(nombre)){
            return ResponseEntity.noContent().build();
        }else{
            return ResponseEntity.notFound().build();

        }
    }
}
