package cl.duoc.sistemagestionproductos.repository;

import java.util.ArrayList;
import java.util.List;
import org.springframework.stereotype.Repository;
import cl.duoc.sistemagestionproductos.model.Producto;

@Repository
public class ProductoRepository {

    private List<Producto> listaProductos = new ArrayList<>();

    public List<Producto> mostrarProductos(){
        return listaProductos;
    }

    public void agregarProducto(Producto producto){
        listaProductos.add(producto);
    }

    public boolean eliminarProducto(String nombre){
        return listaProductos.removeIf(producto -> producto.getNombre().equals(nombre));
    }
}
