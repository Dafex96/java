package cl.duoc.sistemagestionproductos;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SistemagestionproductosApplication {

	public static void main(String[] args) {
		SpringApplication.run(SistemagestionproductosApplication.class, args);
		System.out.println("Running");
	}

}
