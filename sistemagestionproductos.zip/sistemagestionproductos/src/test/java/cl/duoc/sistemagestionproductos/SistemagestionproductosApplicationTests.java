package cl.duoc.sistemagestionproductos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SistemagestionproductosApplicationTests {

	@Test
	void contextLoads() {
	}

}
