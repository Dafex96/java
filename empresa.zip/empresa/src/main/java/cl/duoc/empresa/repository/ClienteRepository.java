package cl.duoc.empresa.repository;

import java.util.ArrayList;
import java.util.List;
import org.springframework.stereotype.Repository;
import cl.duoc.empresa.model.Cliente;

@Repository
public class ClienteRepository {

    private List<Cliente> listaClientes = new ArrayList<>();

    public List<Cliente> obtenerClientes(){
        return listaClientes;
    }
    
    public Cliente guardarCliente(Cliente cliente){
        listaClientes.add(cliente);
        return cliente;
    }

    public void eliminarPorCorreo(String correo){
        listaClientes.removeIf(cliente -> cliente.getCorreo().equals(correo));
    }
}
