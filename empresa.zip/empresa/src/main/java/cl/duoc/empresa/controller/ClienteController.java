package cl.duoc.empresa.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
import cl.duoc.empresa.model.Cliente;
import cl.duoc.empresa.service.ClienteService;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

@RestController
@RequestMapping("/api/v1/clientes")
public class ClienteController {

    @Autowired
    private ClienteService clienteService;

    @GetMapping
    @ResponseStatus(HttpStatus.OK)
    public List<Cliente> listarClientes(){
        return clienteService.getClientes();
    }

    @PostMapping
    @ResponseStatus(HttpStatus.OK)
    public Cliente agregarCliente(@RequestBody Cliente cliente){
        return clienteService.saveCliente(cliente);
    }
    
    @DeleteMapping("{correo}")
    public String eliminarCliente(@PathVariable String correo){

        
         return clienteService.deleteCliente(correo);
        
    }
}
