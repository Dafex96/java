package cl.duoc.empresa.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import cl.duoc.empresa.model.Cliente;
import cl.duoc.empresa.repository.ClienteRepository;

@Service
public class ClienteService {

    @Autowired
    private ClienteRepository clienteRepository;

    public List<Cliente> getClientes(){
        return clienteRepository.obtenerClientes();
    }

    public Cliente saveCliente(Cliente cliente){
        return clienteRepository.guardarCliente(cliente);
    }

    public String deleteCliente(String correo){
        clienteRepository.eliminarPorCorreo(correo);
        return "Cliente Eliminado";
    }
}
