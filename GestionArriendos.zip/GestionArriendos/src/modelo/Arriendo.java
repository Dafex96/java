package modelo;

public class Arriendo {
    
    private int id;
    private String arrendatario;
    private int plazo;
    private double precio;

    public Arriendo() {
    }

    public Arriendo(int id, String arrendatario, int plazo, double precio) {
        this.id = id;
        this.arrendatario = arrendatario;
        this.plazo = plazo;
        this.precio = precio;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getArrendatario() {
        return arrendatario;
    }

    public void setArrendatario(String arrendatario) {
        this.arrendatario = arrendatario;
    }

    public int getPlazo() {
        return plazo;
    }

    public void setPlazo(int plazo) {
        this.plazo = plazo;
    }

    public double getPrecio() {
        return precio;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }
    
    
    
    
}
