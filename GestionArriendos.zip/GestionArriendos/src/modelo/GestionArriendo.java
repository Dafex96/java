package modelo;

import java.util.ArrayList;

public class GestionArriendo {
    
    private ArrayList<Arriendo> listaArriendos;

    public GestionArriendo() {
        listaArriendos = new ArrayList<Arriendo>();
    }

    public void insertar(Arriendo arri){
        listaArriendos.add(arri);
    }
    
    public Arriendo buscarPorID(int id){
        
        for (Arriendo arri : listaArriendos) {
            
            if (arri.getId() == id) {
                return arri;
            }
        }
        return null;
    }
    
    public boolean actualizar(Arriendo arriendoActualizar) {
        for (Arriendo arriendoLista : listaArriendos) {
            if (arriendoLista.getId() == arriendoActualizar.getId()) {
                
                arriendoLista.setArrendatario(arriendoActualizar.getArrendatario());
                arriendoLista.setPlazo(arriendoActualizar.getPlazo());
                arriendoLista.setPrecio(arriendoActualizar.getPrecio());
                
                return true;
            }
        }
        return false;
    }
    
    public boolean eliminar(int id){
        Arriendo arri = buscarPorID(id);
        
        if (arri != null) {
            listaArriendos.remove(arri);
            return true;
        }
        return false;
    }
    
    public ArrayList<Arriendo> listar(){
        return listaArriendos;
    }
    
    
}