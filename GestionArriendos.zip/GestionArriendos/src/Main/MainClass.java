package Main;

import vista.VistaArriendo;

public class MainClass {
    
    public static void main(String[] args) {
        
        VistaArriendo vista = new VistaArriendo();
        vista.setVisible(true);
        
        
    }
    
    
}
