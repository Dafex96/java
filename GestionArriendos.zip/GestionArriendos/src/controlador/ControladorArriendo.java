package controlador;
import java.util.ArrayList;
import modelo.Arriendo;
import modelo.GestionArriendo;

public class ControladorArriendo {
    
    private GestionArriendo gestion;

    public ControladorArriendo() {
        gestion = new GestionArriendo();
    }
    
    public void registrarArriendo(int id, String arrendatario, int plazo, double precio){
        Arriendo arri = new Arriendo(id, arrendatario, plazo, precio);
            gestion.insertar(arri);
    }
    
    public ArrayList<Arriendo> obtenerArriendos(){
        return gestion.listar();
    }
    
    public boolean eliminarArriendo(int id){
        return gestion.eliminar(id);
    }
    
    public Arriendo buscarPorId(int id){
        return gestion.buscarPorID(id);
    }
    
    public boolean actualizarArriendo(int id, String arrendatario, int plazo, double precio){
        Arriendo arri = new Arriendo(id,arrendatario,plazo,precio);
        return gestion.actualizar(arri);
    }
    
    
}
