package cl.duoc.bibliotecaduoc.repository;

import java.util.ArrayList;
import java.util.List;
import org.springframework.stereotype.Repository;
import cl.duoc.bibliotecaduoc.model.Libro;

@Repository
public class LibroRepositorio {

    private List<Libro> listaLibros = new ArrayList<>();

    public void LibroRepository(){
        listaLibros.add(new Libro(1, "1234", "Papelucho", "Salamanca", "1997", "Marcela Paz"));
        listaLibros.add(new Libro(2, "2345", "Don Quijote de la Mancha", "Francisco de Robles", "1605", "Miguel de Cervantes"));
        listaLibros.add(new Libro(3, "3456", "Cien Años de Soledad", "Sudamericana", "1967", "Gabriel García Márquez"));
        listaLibros.add(new Libro(4, "4567", "La Odisea", "Clásicos Universales", "800 a.C.", "Homero"));
        listaLibros.add(new Libro(5, "5678", "El Principito", "Reynal & Hitchcock", "1943", "Antoine de Saint-Exupéry"));
        listaLibros.add(new Libro(6, "6789", "1984", "Secker & Warburg", "1949", "George Orwell"));
        listaLibros.add(new Libro(7, "7890", "Fahrenheit 451", "Ballantine Books", "1953", "Ray Bradbury"));
        listaLibros.add(new Libro(8, "8901", "Crónica de una Muerte Anunciada", "Oveja Negra", "1981", "Gabriel García Márquez"));
        listaLibros.add(new Libro(9, "9012", "El Hobbit", "George Allen & Unwin", "1937", "J.R.R. Tolkien"));
        listaLibros.add(new Libro(10, "0123", "Harry Potter y la Piedra Filosofal", "Bloomsbury", "1997", "J.K. Rowling"));
    }

    public List<Libro> obtenerLibros(){
        return listaLibros;
    }

    public Libro guardarLibro(Libro libro){
        listaLibros.add(libro);
        return libro;
    }

    public Libro buscarPorId(int idBuscado){
        for (Libro libro : listaLibros) {
            
            if(libro.getId() == idBuscado){
                return libro;
            }
        }
        return null;
    }

    public Libro buscarPorIsbn(String isbnBuscado){
        for (Libro libro : listaLibros) {
            
            if (libro.getIsbn().equals(isbnBuscado)) {
                return libro;
            }
        }
        return null;
    }

    public Libro actualizar(Libro libroActualizado){
        int posicion = 0;

        for (int i = 0 ; i < listaLibros.size(); i++) {
            if (listaLibros.get(i).getId()  == libroActualizado.getId()) {
                posicion = i;
            }
        }
        listaLibros.set(posicion, libroActualizado);
        return libroActualizado;
    }
    
    public void eliminarLibro(int idEliminar){
        Libro libroEliminado = buscarPorId(idEliminar);
        listaLibros.remove(libroEliminado);
    }



}
