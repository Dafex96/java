package javaapplication2;

public class Vendedor {
    
    private String rut;
    private String nombre;
    private int nroVendedor;
    private String fechaIngreso;
    private Region region;

    public Vendedor() {
    }

    public Vendedor(String rut, String nombre, int nroVendedor, String fechaIngreso, Region region) {
        this.rut = rut;
        this.nombre = nombre;
        this.nroVendedor = nroVendedor;
        this.fechaIngreso = fechaIngreso;
        this.region = region;
    }

    public String getRut() {
        return rut;
    }

    public void setRut(String rut) {
        this.rut = rut;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getNroVendedor() {
        return nroVendedor;
    }

    public void setNroVendedor(int nroVendedor) {
        this.nroVendedor = nroVendedor;
    }

    public String getFechaIngreso() {
        return fechaIngreso;
    }

    public void setFechaIngreso(String fechaIngreso) {
        this.fechaIngreso = fechaIngreso;
    }

    public Region getRegion() {
        return region;
    }

    public void setRegion(Region region) {
        this.region = region;
    }
}
