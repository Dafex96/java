package javaapplication2;

public class Region {
    
    private int nroRegion;
    private String nombre;
    private String ciudadPrincipal;

    public Region() {
    }

    public Region(int nroRegion, String nombre, String ciudadPrincipal) {
        this.nroRegion = nroRegion;
        this.nombre = nombre;
        this.ciudadPrincipal = ciudadPrincipal;
    }

    public int getNroRegion() {
        return nroRegion;
    }

    public void setNroRegion(int nroRegion) {
        this.nroRegion = nroRegion;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getCiudadPrincipal() {
        return ciudadPrincipal;
    }

    public void setCiudadPrincipal(String ciudadPrincipal) {
        this.ciudadPrincipal = ciudadPrincipal;
    }
}
