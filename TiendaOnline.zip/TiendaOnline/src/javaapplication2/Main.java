package javaapplication2;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        
        do{
            System.out.println("--BIENVENIDO A LA TIENDA ONLINE--");
            System.out.println("1) ");
            
            int opcion = input.nextInt();
            
        }while(opcion < 6);
        
        
        
    }
    
}
