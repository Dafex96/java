package javaapplication2;

public class Pedido {
    
    private Cliente cliente;
    private Producto producto;
    private Vendedor vendedor;
    private int cantidad;
    private String fechaPedido;

    public Pedido() {
    }

    public Pedido(Cliente cliente, Producto producto, Vendedor vendedor, int cantidad, String fechaPedido) {
        this.cliente = cliente;
        this.producto = producto;
        this.vendedor = vendedor;
        this.cantidad = cantidad;
        this.fechaPedido = fechaPedido;
    }

    public Cliente getCliente() {
        return cliente;
    }

    public void setCliente(Cliente cliente) {
        this.cliente = cliente;
    }

    public Producto getProducto() {
        return producto;
    }

    public void setProducto(Producto producto) {
        this.producto = producto;
    }

    public Vendedor getVendedor() {
        return vendedor;
    }

    public void setVendedor(Vendedor vendedor) {
        this.vendedor = vendedor;
    }

    public int getCantidad() {
        return cantidad;
    }

    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }

    public String getFechaPedido() {
        return fechaPedido;
    }

    public void setFechaPedido(String fechaPedido) {
        this.fechaPedido = fechaPedido;
    }
}
