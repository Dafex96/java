package cl.duoc.bibliotecaduoc.repository;

import java.util.ArrayList;
import java.util.List;
import org.springframework.stereotype.Repository;
import cl.duoc.bibliotecaduoc.model.Libro;

@Repository
public class LibroRepositorio {

    private List<Libro> listaLibros = new ArrayList<>();

    public List<Libro> obtenerLibros(){
        return listaLibros;
    }

    public Libro guardarLibro(Libro libro){
        listaLibros.add(libro);
        return libro;
    }

    public Libro buscarPorId(int idBuscado){
        for (Libro libro : listaLibros) {
            
            if(libro.getId() == idBuscado){
                return libro;
            }
        }
        return null;
    }

    public Libro buscarPorIsbn(String isbnBuscado){
        for (Libro libro : listaLibros) {
            
            if (libro.getIsbn().equals(isbnBuscado)) {
                return libro;
            }
        }
        return null;
    }

    public Libro actualizar(Libro libroActualizado){
        int posicion = 0;

        for (int i = 0 ; i < listaLibros.size(); i++) {
            if (listaLibros.get(i).getId()  == libroActualizado.getId()) {
                posicion = i;
            }
        }
        listaLibros.set(posicion, libroActualizado);
        return libroActualizado;
    }
    
    public void eliminarLibro(int idEliminar){
        Libro libroEliminado = buscarPorId(idEliminar);
        listaLibros.remove(libroEliminado);
    }






}
