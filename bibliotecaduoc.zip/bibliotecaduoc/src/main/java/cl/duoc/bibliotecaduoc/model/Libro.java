package cl.duoc.bibliotecaduoc.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data // Getters y Setters
@AllArgsConstructor // Contructor con todos los argumentos
@NoArgsConstructor // Constuctor vacio
public class Libro {

    private int id;
    private String isbn;
    private String titulo;
    private String editorial;
    private String fechaPublicacion;
    private String autor;

    

}
